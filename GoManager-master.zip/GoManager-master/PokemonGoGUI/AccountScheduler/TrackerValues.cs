﻿namespace PokemonGoGUI.AccountScheduler
{
    public class TrackerValues
    {
        public int Pokemon { get; set; }
        public int Pokestops { get; set; }
    }
}
