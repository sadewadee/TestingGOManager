﻿namespace PokemonGoGUI.Enums
{
    public enum BotState
    {
        Stopped,
        Stopping,
        Starting,
        Running,
        Waiting,
        Pausing,
        Paused
    };
}
