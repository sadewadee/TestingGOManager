﻿namespace PokemonGoGUI.Enums
{
    public enum CheckType
    {
        False = 0,
        True = 1,
        Toggle = 2
    };
}
