﻿namespace PokemonGoGUI.Enums
{
    public enum SchedulerOption
    {
        Nothing,
        StartStop,
        //PauseUnPause,
        DisableEnable
    };
}
