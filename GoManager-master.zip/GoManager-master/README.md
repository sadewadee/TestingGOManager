# GoManager

I'll make this pretty later


<h2><a name="credits">Credits</a></h2>

NECROBOTIO - [Updated RocketAPI & Various Methods] (https://github.com/NECROBOTIO/NecroBot)

FeroxRev - [RocketAPI](https://github.com/FeroxRev/Pokemon-Go-Rocket-API)

LineWalker - [POGOProtos-0.31.0](https://github.com/Linewalker/POGOProtos-0.31.0)

AeonLucid - [POGOProtos](https://github.com/AeonLucid/POGOProtos)
